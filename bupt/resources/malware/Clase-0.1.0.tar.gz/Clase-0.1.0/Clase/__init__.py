# the purpose is to make everyone pay attention to software supply chain attacks, because the risks are too great. 
